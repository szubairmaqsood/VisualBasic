﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("IbrahimAlradaddiAssignment1")>
<Assembly: AssemblyDescription("In this project we will learn how to use read and write command and how to use my object")>
<Assembly: AssemblyCompany("Basil Ibrahim Alraddadi")>
<Assembly: AssemblyProduct("IbrahimAlradaddiAssignment1")>
<Assembly: AssemblyCopyright("Basil Ibrahim Alraddadi")>
<Assembly: AssemblyTrademark("")>

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("e731d061-1479-4d2b-bf86-88ffb4af2df7")>

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")>

<Assembly: AssemblyVersion("1.0.0.1")>
<Assembly: AssemblyFileVersion("1.0.0.0")>
